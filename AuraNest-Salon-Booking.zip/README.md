# AuraNest Salon Studio

A fictional premium salon booking demo with:
- React-style modern frontend (vanilla HTML/CSS/JS for zero-build simplicity)
- Express + SQLite backend
- 3-chair hair capacity
- 1-chair other-service capacity
- Server-side availability validation
- ₹29 demo advance payment flow
- UPI number / UPI ID / demo QR UI

## Run
npm install
npm start

Open http://localhost:3000

This project uses fictional business and payment information. The QR/payment step is a demo and does not process real money.
