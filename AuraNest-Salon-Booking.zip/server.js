import express from "express";
import cors from "cors";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __dirname=path.dirname(fileURLToPath(import.meta.url));
const app=express(), PORT=process.env.PORT||3000;
app.use(cors()); app.use(express.json()); app.use(express.static(path.join(__dirname,"public")));

const db=new Database("auranest.db");
db.exec(`CREATE TABLE IF NOT EXISTS bookings(
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, phone TEXT NOT NULL,
 email TEXT, service TEXT NOT NULL, category TEXT NOT NULL, date TEXT NOT NULL,
 time TEXT NOT NULL, duration INTEGER, price INTEGER, advance INTEGER DEFAULT 29,
 payment_status TEXT DEFAULT 'PENDING', status TEXT DEFAULT 'RESERVED',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
);`);

const services=[
["Haircut","hair","30 min",299],["Haircut + Beard","hair","45 min",449],
["Hair Styling","hair","45 min",399],["Hair Wash & Conditioning","hair","30 min",249],
["Blow Dry","hair","30 min",299],["Hair Spa","hair","60 min",799],
["Beard Trim","other","20 min",199],["Beard Styling","other","25 min",249],
["Cleanup","other","45 min",499],["Facial","other","60 min",899],
["Face Massage","other","30 min",399],["Manicure","other","45 min",499],
["Pedicure","other","45 min",599],["Full Arms Waxing","other","30 min",499],
["Half Legs Waxing","other","30 min",399],["Full Legs Waxing","other","45 min",699],
["Head Massage","other","30 min",399],["Premium Grooming Package","other","90 min",1299]
].map(([name,category,duration,price])=>({name,category,duration,price}));

app.get("/api/services",(_,res)=>res.json(services));

function count(date,time,category){
 return db.prepare("SELECT COUNT(*) c FROM bookings WHERE date=? AND time=? AND category=? AND status IN ('RESERVED','CONFIRMED')").get(date,time,category).c;
}
app.get("/api/availability",(req,res)=>{
 const {date,service}=req.query; const s=services.find(x=>x.name===service);
 if(!date||!s) return res.status(400).json({error:"Invalid date or service"});
 const slots=[];
 for(let h=9;h<=20;h++) for(let m of [0,30]){
   if(h===20&&m===30) continue;
   const time=`${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}`;
   const used=count(date,time,s.category), cap=s.category==="hair"?3:1;
   slots.push({time,used,capacity:cap,available:used<cap});
 }
 res.json(slots);
});

app.post("/api/bookings",(req,res)=>{
 const {name,phone,email,service,date,time}=req.body;
 const s=services.find(x=>x.name===service);
 if(!name||!/^\d{10}$/.test(phone)||!s||!date||!time) return res.status(400).json({error:"Please enter valid booking details."});
 const today=new Date(); today.setHours(0,0,0,0);
 const chosen=new Date(date+"T00:00:00");
 if(chosen<today) return res.status(400).json({error:"Past dates cannot be booked."});
 const cap=s.category==="hair"?3:1;
 const tx=db.transaction(()=>{
   const used=count(date,time,s.category);
   if(used>=cap) throw new Error("SLOT_FULL");
   const r=db.prepare(`INSERT INTO bookings(name,phone,email,service,category,date,time,duration,price)
     VALUES(?,?,?,?,?,?,?,?,?)`).run(name,phone,email||"",service,s.category,date,time,
     parseInt(s.duration),s.price);
   return r.lastInsertRowid;
 });
 try{
   const id=tx();
   res.json({success:true,booking:{id,name,phone,email,service,date,time,price:s.price,advance:29,remaining:s.price-29,status:"RESERVED"}});
 }catch(e){ if(e.message==="SLOT_FULL") return res.status(409).json({error:"Sorry, this slot was just booked. Please select another time."}); throw e; }
});

app.post("/api/bookings/:id/pay",(req,res)=>{
 const id=Number(req.params.id);
 const r=db.prepare("UPDATE bookings SET payment_status='DEMO_PAID',status='CONFIRMED' WHERE id=?").run(id);
 if(!r.changes) return res.status(404).json({error:"Booking not found"});
 res.json({success:true});
});

app.get("/api/bookings/:id",(req,res)=>{
 const b=db.prepare("SELECT * FROM bookings WHERE id=?").get(Number(req.params.id));
 b?res.json(b):res.status(404).json({error:"Not found"});
});

app.get("*",(req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
app.listen(PORT,()=>console.log(`AuraNest running on port ${PORT}`));
